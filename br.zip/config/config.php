<?php

return [
    // Databáze
    'db' => [
        'host' => 'localhost:3306',
        'dbname' => 'shoptet_bloomreach',
        'user' => 'shoptet_br',
        'password' => '1z7S6ng7~',
        'charset' => 'utf8mb4',
    ],

    // Shoptet API
    'shoptet' => [
        'signature_key' => 'YOUR_SHOPTET_API_KEY', 
        'access_token' => '173796-p-189106-drpzd8nlobailebj3o21uzozipv2m288', 

    ],

    // Bloomreach API
    'bloomreach' => [
        'apiEndpoint' => 'YOUR_BLOOMREACH_API_ENDPOINT',
        'apiKey' => 'YOUR_BLOOMREACH_API_KEY', // Pokud je potřeba
    ],

    // Guzzle (HTTP klient)
    'guzzle' => [
        'timeout' => 30, // časový limit v sekundách pro celý request
    ],
];